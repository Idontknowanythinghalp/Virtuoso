import React from "react";
import { CmsShell } from "@/components/layout/CmsShell";
import { ImportPreparationClient } from "@/components/imports/ImportPreparationClient";
import { requireActiveUser } from "@/lib/auth/guards";
import { ALL_ORGANISER_ROLES } from "@/lib/auth/policy";
import { siteConfig } from "@/lib/site-config";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import type { EventRecord } from "@/types/competition";
import type { ImportEventOption } from "@/types/imports";

export const dynamic = "force-dynamic";

async function loadImportEvents(): Promise<{
  events: ImportEventOption[];
  migrationMissing: boolean;
}> {
  const supabase = await createSupabaseServerClient();
  const { data, error } = await supabase
    .from("events")
    .select(
      "id, code, name, entry_mode, codename_mode, status, min_team_size, max_team_size",
    )
    .order("created_at", { ascending: false })
    .returns<
      Pick<
        EventRecord,
        | "id"
        | "code"
        | "name"
        | "entry_mode"
        | "codename_mode"
        | "status"
        | "min_team_size"
        | "max_team_size"
      >[]
    >();

  if (error || !data) {
    return { events: [], migrationMissing: Boolean(error) };
  }

  return { events: data, migrationMissing: false };
}

export default async function ImportPreparationPage() {
  const { sessionUser } = await requireActiveUser(ALL_ORGANISER_ROLES, {
    routeLabel: "/imports",
  });

  const { events, migrationMissing } = await loadImportEvents();

  return (
    <CmsShell
      user={sessionUser}
      breadcrumbs={[
        { label: siteConfig.appName, href: "/" },
        { label: "Registration Import Preparation" },
      ]}
    >
      <section className="space-y-2 border-b border-slate-200 pb-6">
        <p className="text-xs font-medium text-[#4B0507]">
          Stage 2B.1 · Registration Import Preparation
        </p>
        <h1 className="font-display text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
          Registration Import Preparation
        </h1>
        <p className="max-w-3xl text-sm leading-relaxed text-slate-600 sm:text-base">
          Upload exported CSV or Excel (.xlsx) registration files from the
          college registration system, map source columns to CMS fields, and
          inspect server-validated rows before database import execution is
          enabled in Stage 2B.2.
        </p>
      </section>

      <ImportPreparationClient
        events={events}
        migrationMissing={migrationMissing}
      />
    </CmsShell>
  );
}
