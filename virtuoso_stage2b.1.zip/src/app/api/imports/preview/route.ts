import { NextRequest, NextResponse } from "next/server";
import {
  OrganiserAuthError,
  requireActiveUserForAction,
} from "@/lib/auth/guards";
import { ALL_ORGANISER_ROLES } from "@/lib/auth/policy";
import { validateUuid } from "@/lib/competition/validation";
import {
  ALL_TARGET_FIELD_KEYS,
  createEmptyMapping,
} from "@/lib/imports/fields";
import { MAX_IMPORT_COLUMNS, MAX_IMPORT_ROWS } from "@/lib/imports/parser";
import {
  validateImportBatch,
  type ExistingContingentLookupItem,
  type ExistingParticipantLookupItem,
} from "@/lib/imports/validator";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import type { EventRecord } from "@/types/competition";
import type {
  ColumnMappingState,
  DetectedColumn,
  ImportEventOption,
  ImportTargetFieldKey,
  ParsedDataRow,
} from "@/types/imports";

export const runtime = "nodejs";

function sanitizeMappingInput(raw: unknown): ColumnMappingState {
  const clean = createEmptyMapping();
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return clean;
  }
  const source = raw as Record<string, unknown>;
  for (const key of ALL_TARGET_FIELD_KEYS) {
    if (Object.prototype.hasOwnProperty.call(source, key)) {
      const value = source[key];
      clean[key] = typeof value === "string" && value.trim() ? value.trim() : null;
    }
  }
  return clean;
}

function sanitizeRequiredOverrides(raw: unknown): ImportTargetFieldKey[] {
  if (!Array.isArray(raw)) return [];
  const allowed = new Set<string>(ALL_TARGET_FIELD_KEYS);
  const out: ImportTargetFieldKey[] = [];
  for (const item of raw) {
    if (typeof item === "string" && allowed.has(item) && !out.includes(item as ImportTargetFieldKey)) {
      out.push(item as ImportTargetFieldKey);
    }
  }
  return out;
}

function sanitizeColumns(raw: unknown): DetectedColumn[] | null {
  if (!Array.isArray(raw) || raw.length === 0 || raw.length > MAX_IMPORT_COLUMNS) {
    return null;
  }
  const columns: DetectedColumn[] = [];
  for (let i = 0; i < raw.length; i += 1) {
    const item = raw[i];
    if (!item || typeof item !== "object") return null;
    const obj = item as Record<string, unknown>;
    if (
      typeof obj.key !== "string" ||
      typeof obj.index !== "number" ||
      !Number.isInteger(obj.index) ||
      obj.index < 0 ||
      obj.index >= raw.length ||
      typeof obj.headerName !== "string"
    ) {
      return null;
    }
    columns.push({
      key: obj.key,
      index: obj.index,
      headerName: obj.headerName,
      displayLabel:
        typeof obj.displayLabel === "string" ? obj.displayLabel : obj.headerName,
      isDuplicateHeader: Boolean(obj.isDuplicateHeader),
      duplicateOccurrence:
        typeof obj.duplicateOccurrence === "number" ? obj.duplicateOccurrence : 1,
      duplicateTotal:
        typeof obj.duplicateTotal === "number" ? obj.duplicateTotal : 1,
      nonEmptyCount:
        typeof obj.nonEmptyCount === "number" ? obj.nonEmptyCount : 0,
      sampleValues: Array.isArray(obj.sampleValues)
        ? obj.sampleValues.filter((v): v is string => typeof v === "string").slice(0, 3)
        : [],
    });
  }
  return columns;
}

function sanitizeRows(raw: unknown, columnCount: number): ParsedDataRow[] | null {
  if (!Array.isArray(raw) || raw.length === 0 || raw.length > MAX_IMPORT_ROWS) {
    return null;
  }
  const rows: ParsedDataRow[] = [];
  for (const item of raw) {
    if (!item || typeof item !== "object") return null;
    const obj = item as Record<string, unknown>;
    if (
      typeof obj.rowNumber !== "number" ||
      !Number.isInteger(obj.rowNumber) ||
      obj.rowNumber < 1 ||
      !Array.isArray(obj.cells)
    ) {
      return null;
    }
    const cells = Array.from({ length: columnCount }, (_, idx) => {
      const val = obj.cells && Array.isArray(obj.cells) ? obj.cells[idx] : "";
      return typeof val === "string" ? val : String(val ?? "");
    });
    rows.push({ rowNumber: obj.rowNumber, cells });
  }
  return rows;
}

export async function POST(request: NextRequest) {
  try {
    await requireActiveUserForAction(ALL_ORGANISER_ROLES, {
      actionName: "import.validate_preview",
    });

    let body: Record<string, unknown>;
    try {
      const parsed = await request.json();
      if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
        return NextResponse.json(
          { ok: false, error: "Invalid JSON request body." },
          { status: 400 },
        );
      }
      body = parsed as Record<string, unknown>;
    } catch {
      return NextResponse.json(
        { ok: false, error: "Unable to parse request JSON body." },
        { status: 400 },
      );
    }

    const eventCheck = validateUuid(
      typeof body.eventId === "string" ? body.eventId : "",
      "Event",
    );
    if (!eventCheck.ok) {
      return NextResponse.json(
        { ok: false, error: eventCheck.error },
        { status: 400 },
      );
    }

    const columns = sanitizeColumns(body.columns);
    if (!columns) {
      return NextResponse.json(
        {
          ok: false,
          error: "Uploaded column metadata is missing or invalid. Re-upload the registration file.",
        },
        { status: 400 },
      );
    }

    const rows = sanitizeRows(body.rows, columns.length);
    if (!rows) {
      return NextResponse.json(
        {
          ok: false,
          error: "Parsed registration rows are missing or exceed the row limit.",
        },
        { status: 400 },
      );
    }

    const mapping = sanitizeMappingInput(body.mapping);
    const requiredOverrides = sanitizeRequiredOverrides(body.requiredFields);

    const supabase = await createSupabaseServerClient();
    const { data: eventRow, error: eventErr } = await supabase
      .from("events")
      .select(
        "id, code, name, entry_mode, codename_mode, status, min_team_size, max_team_size",
      )
      .eq("id", eventCheck.value)
      .maybeSingle<
        Pick<
          EventRecord,
          | "id"
          | "code"
          | "name"
          | "entry_mode"
          | "codename_mode"
          | "status"
          | "min_team_size"
          | "max_team_size"
        >
      >();

    if (eventErr) {
      return NextResponse.json(
        {
          ok: false,
          error:
            "Stage 2A database tables are unavailable or inaccessible. Verify migration 0003 and RLS policies.",
        },
        { status: 503 },
      );
    }

    if (!eventRow) {
      return NextResponse.json(
        { ok: false, error: "Selected competition event was not found." },
        { status: 404 },
      );
    }

    // Read-only lookups under active organiser RLS for existing CMS match warnings (zero mutations)
    const [{ data: contingentsData }, { data: participantsData }, { data: entriesData }] =
      await Promise.all([
        supabase
          .from("contingents")
          .select("id, contingent_code, name, institution_name, external_registration_ref")
          .returns<ExistingContingentLookupItem[]>(),
        supabase
          .from("participants")
          .select("id, participant_code, full_name, email, external_registration_ref, contingent_id")
          .returns<ExistingParticipantLookupItem[]>(),
        supabase
          .from("event_entries")
          .select("contingent_id, participant_id")
          .eq("event_id", eventRow.id),
      ]);

    const enteredContingentIds = new Set<string>();
    const enteredParticipantIds = new Set<string>();
    for (const entry of entriesData ?? []) {
      const typed = entry as {
        contingent_id: string | null;
        participant_id: string | null;
      };
      if (typed.contingent_id) enteredContingentIds.add(typed.contingent_id);
      if (typed.participant_id) enteredParticipantIds.add(typed.participant_id);
    }

    const eventOption: ImportEventOption = {
      id: eventRow.id,
      code: eventRow.code,
      name: eventRow.name,
      entry_mode: eventRow.entry_mode,
      codename_mode: eventRow.codename_mode,
      status: eventRow.status,
      min_team_size: eventRow.min_team_size,
      max_team_size: eventRow.max_team_size,
    };

    const report = validateImportBatch({
      event: eventOption,
      columns,
      rows,
      mapping,
      requiredOverrides,
      existingContext: {
        contingents: contingentsData ?? [],
        participants: participantsData ?? [],
        enteredContingentIdsForEvent: enteredContingentIds,
        enteredParticipantIdsForEvent: enteredParticipantIds,
      },
    });

    return NextResponse.json({ ok: true, report });
  } catch (err) {
    if (err instanceof OrganiserAuthError) {
      return NextResponse.json(
        { ok: false, error: err.message },
        { status: err.status },
      );
    }
    return NextResponse.json(
      { ok: false, error: "Unexpected server error while validating import preview." },
      { status: 500 },
    );
  }
}
