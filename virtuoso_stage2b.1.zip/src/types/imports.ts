import type {
  CodenameMode,
  EventEntryMode,
  EventEntryStatus,
  EventEntryType,
  EventStatus,
} from "@/types/competition";

export type ImportFileFormat = "csv" | "xlsx";

export type ImportTargetEntity = "contingent" | "participant" | "event_entry";

export type ImportTargetFieldKey =
  | "contingent_code"
  | "contingent_name"
  | "institution_name"
  | "institution_city"
  | "contingent_external_ref"
  | "contact_email"
  | "contact_phone"
  | "contingent_notes"
  | "participant_code"
  | "full_name"
  | "email"
  | "phone"
  | "participant_external_ref"
  | "is_contingent_lead"
  | "entry_type"
  | "entry_status"
  | "entry_notes"
  | "source_event_code";

export interface ImportTargetFieldDefinition {
  key: ImportTargetFieldKey;
  entity: ImportTargetEntity;
  label: string;
  schemaColumn: string;
  description: string;
  aliases: readonly string[];
}

export interface DetectedColumn {
  /** Unique positional column identifier (e.g. "col_0") so duplicate headings stay distinct. */
  key: string;
  /** 0-based column index in the uploaded sheet. */
  index: number;
  /** Raw trimmed heading text from the spreadsheet header row (or fallback label if blank). */
  headerName: string;
  /** Display label distinguishing duplicate headers, e.g. "Email (Column 5 · 2 of 2)". */
  displayLabel: string;
  /** True when another column in the same sheet shares the same normalized headerName. */
  isDuplicateHeader: boolean;
  /** 1-based occurrence counter among columns with the same headerName. */
  duplicateOccurrence: number;
  /** Total columns in this sheet sharing the same headerName. */
  duplicateTotal: number;
  /** Non-empty values seen in this column across parsed data rows. */
  nonEmptyCount: number;
  /** Up to 3 non-empty sample values for column inspection. */
  sampleValues: string[];
}

export interface ParsedDataRow {
  /** Original 1-based spreadsheet row number (accounts for header + skipped blank rows). */
  rowNumber: number;
  /** Positional string cells aligned by index with ParsedImportSheet.columns. */
  cells: string[];
}

export interface ParsedImportSheet {
  sheetName: string;
  columns: DetectedColumn[];
  rows: ParsedDataRow[];
  totalRawRows: number;
  skippedEmptyRowCount: number;
  warnings: string[];
}

export interface ParsedImportWorkbook {
  fileName: string;
  fileFormat: ImportFileFormat;
  fileSizeBytes: number;
  sheetNames: string[];
  selectedSheetName: string;
  sheet: ParsedImportSheet;
}

/** Maps a target CMS field key to a unique source DetectedColumn.key, or null if unmapped. */
export type ColumnMappingState = Record<ImportTargetFieldKey, string | null>;

export interface ImportEventOption {
  id: string;
  code: string;
  name: string;
  entry_mode: EventEntryMode;
  codename_mode: CodenameMode;
  status: EventStatus;
  min_team_size: number | null;
  max_team_size: number | null;
}

export type ImportIssueSeverity = "error" | "warning";

export type ImportIssueCategory =
  | "missing_required"
  | "invalid_value"
  | "duplicate_in_file"
  | "event_compatibility"
  | "schema_rule";

export interface ImportRowIssue {
  field: ImportTargetFieldKey | "row";
  severity: ImportIssueSeverity;
  category: ImportIssueCategory;
  message: string;
}

export interface InFileDuplicateNotice {
  field:
    | "participant_code"
    | "email"
    | "participant_external_ref"
    | "contingent_conflict"
    | "contingent_member_name"
    | "individual_identity";
  value: string;
  matchingRowNumbers: number[];
  message: string;
}

export interface ExistingCmsMatchNotice {
  entity: "contingent" | "participant" | "event_entry";
  matchedBy:
    | "contingent_code"
    | "external_registration_ref"
    | "participant_code"
    | "email"
    | "already_entered_in_event";
  existingId: string;
  existingLabel: string;
  alreadyEnteredInSelectedEvent: boolean;
  message: string;
}

export interface NormalizedImportRowPreview {
  entryType: EventEntryType;
  entryStatus: EventEntryStatus;
  entryNotes: string | null;
  sourceEventCode: string | null;
  contingent: {
    contingentCode: string | null;
    name: string | null;
    institutionName: string | null;
    institutionCity: string | null;
    externalRegistrationRef: string | null;
    contactEmail: string | null;
    contactPhone: string | null;
    notes: string | null;
  } | null;
  participant: {
    participantCode: string | null;
    fullName: string | null;
    email: string | null;
    phone: string | null;
    institutionName: string | null;
    externalRegistrationRef: string | null;
    isContingentLead: boolean;
  };
}

export interface ImportPreviewRow {
  rowNumber: number;
  status: "valid" | "invalid";
  resolvedEntryType: EventEntryType;
  normalized: NormalizedImportRowPreview;
  issues: ImportRowIssue[];
  inFileDuplicates: InFileDuplicateNotice[];
  existingMatches: ExistingCmsMatchNotice[];
}

export interface ImportValidationSummary {
  totalRows: number;
  validRows: number;
  invalidRows: number;
  inFileDuplicateRows: number;
  existingMatchRows: number;
  missingRequiredFieldCount: number;
  unmappedSourceColumnsCount: number;
  unmappedTargetFieldsCount: number;
}

export interface ImportValidationReport {
  event: ImportEventOption;
  requiredTargetFields: ImportTargetFieldKey[];
  missingRequiredTargetFields: ImportTargetFieldKey[];
  unmappedSourceColumns: DetectedColumn[];
  unmappedTargetFields: ImportTargetFieldKey[];
  summary: ImportValidationSummary;
  previewRows: ImportPreviewRow[];
  batchNotices: string[];
}
