"use client";

import React, { useMemo, useRef, useState } from "react";
import Link from "next/link";
import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  FileSpreadsheet,
  RotateCcw,
  ShieldCheck,
  Sparkles,
  Upload,
  XCircle,
} from "lucide-react";
import {
  ALL_TARGET_FIELD_KEYS,
  IMPORT_FIELD_BY_KEY,
  IMPORT_FIELD_DEFINITIONS,
  createEmptyMapping,
  getSchemaBaselineRequiredFields,
  suggestColumnMappings,
} from "@/lib/imports/fields";
import {
  CODENAME_MODE_LABELS,
  ENTRY_MODE_LABELS,
  ENTRY_STATUS_LABELS,
  EVENT_STATUS_LABELS,
} from "@/types/competition";
import type {
  ColumnMappingState,
  ImportEventOption,
  ImportTargetEntity,
  ImportTargetFieldKey,
  ImportValidationReport,
  ParsedImportWorkbook,
} from "@/types/imports";

interface ImportPreparationClientProps {
  events: ImportEventOption[];
  migrationMissing?: boolean;
}

type WorkflowStep = 1 | 2 | 3 | 4 | 5 | 6;
type PreviewFilter =
  | "all"
  | "valid"
  | "invalid"
  | "duplicates"
  | "existing_matches";

const STEP_LABELS: Array<{ step: WorkflowStep; title: string }> = [
  { step: 1, title: "Select Event" },
  { step: 2, title: "Upload File" },
  { step: 3, title: "Inspect Columns" },
  { step: 4, title: "Map Columns" },
  { step: 5, title: "Validate" },
  { step: 6, title: "Review Preview" },
];

const ENTITY_SECTION_META: Array<{
  entity: ImportTargetEntity;
  heading: string;
  description: string;
}> = [
  {
    entity: "contingent",
    heading: "Contingent & Institution Fields",
    description:
      "Maps to public.contingents (and shares institution_name with participants).",
  },
  {
    entity: "participant",
    heading: "Participant Fields",
    description:
      "Maps to public.participants. Contingent members share a contingent code across rows.",
  },
  {
    entity: "event_entry",
    heading: "Event Entry & Cross-Check Fields",
    description:
      "Maps to public.event_entries or cross-checks source event references against the selected event.",
  },
];

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export function ImportPreparationClient({
  events,
  migrationMissing = false,
}: ImportPreparationClientProps) {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const [step, setStep] = useState<WorkflowStep>(1);
  const [selectedEventId, setSelectedEventId] = useState<string>(
    events.find((e) => e.status !== "archived")?.id ?? events[0]?.id ?? "",
  );

  const [workbook, setWorkbook] = useState<ParsedImportWorkbook | null>(null);
  const [mapping, setMapping] = useState<ColumnMappingState>(() =>
    createEmptyMapping(),
  );
  const [organiserRequiredFields, setOrganiserRequiredFields] = useState<
    ImportTargetFieldKey[]
  >([]);
  const [report, setReport] = useState<ImportValidationReport | null>(null);

  const [parseBusy, setParseBusy] = useState(false);
  const [validateBusy, setValidateBusy] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [previewFilter, setPreviewFilter] = useState<PreviewFilter>("all");

  const selectedEvent = useMemo(
    () => events.find((e) => e.id === selectedEventId) ?? null,
    [events, selectedEventId],
  );

  const baselineRequiredSet = useMemo(() => {
    if (!selectedEvent) return new Set<ImportTargetFieldKey>();
    return new Set(getSchemaBaselineRequiredFields(selectedEvent.entry_mode));
  }, [selectedEvent]);

  const effectiveRequiredSet = useMemo(() => {
    const merged = new Set<ImportTargetFieldKey>(baselineRequiredSet);
    for (const key of organiserRequiredFields) {
      merged.add(key);
    }
    return merged;
  }, [baselineRequiredSet, organiserRequiredFields]);

  const mappedColumnKeys = useMemo(() => {
    const set = new Set<string>();
    for (const key of ALL_TARGET_FIELD_KEYS) {
      const colKey = mapping[key];
      if (colKey) set.add(colKey);
    }
    return set;
  }, [mapping]);

  const unmappedSourceColumns = useMemo(() => {
    if (!workbook) return [];
    return workbook.sheet.columns.filter((col) => !mappedColumnKeys.has(col.key));
  }, [workbook, mappedColumnKeys]);

  const missingRequiredBeforeValidate = useMemo(() => {
    if (!workbook) return [...effectiveRequiredSet];
    const validKeys = new Set(workbook.sheet.columns.map((c) => c.key));
    return ALL_TARGET_FIELD_KEYS.filter(
      (key) =>
        effectiveRequiredSet.has(key) &&
        (!mapping[key] || !validKeys.has(mapping[key]!)),
    );
  }, [workbook, effectiveRequiredSet, mapping]);

  const maxUnlockedStep: WorkflowStep = report
    ? 6
    : workbook
      ? 5
      : selectedEvent
        ? 2
        : 1;

  function handleSelectEvent(nextEventId: string) {
    setSelectedEventId(nextEventId);
    setReport(null);
    setErrorMessage(null);
  }

  async function parseUploadedFile(file: File, requestedSheetName?: string) {
    setParseBusy(true);
    setErrorMessage(null);

    try {
      const formData = new FormData();
      formData.append("file", file);
      if (requestedSheetName) {
        formData.append("sheetName", requestedSheetName);
      }

      const response = await fetch("/api/imports/parse", {
        method: "POST",
        body: formData,
      });

      const payload = (await response.json()) as {
        ok: boolean;
        error?: string;
        workbook?: ParsedImportWorkbook;
      };

      if (!response.ok || !payload.ok || !payload.workbook) {
        setErrorMessage(
          payload.error ?? "Unable to read the uploaded registration file.",
        );
        return;
      }

      setWorkbook(payload.workbook);
      setMapping(suggestColumnMappings(payload.workbook.sheet.columns));
      setReport(null);
      setStep(3);
    } catch {
      setErrorMessage(
        "Network error while uploading the file for inspection. Please retry.",
      );
    } finally {
      setParseBusy(false);
    }
  }

  async function handleFileInputChange(
    event: React.ChangeEvent<HTMLInputElement>,
  ) {
    const file = event.target.files?.[0] ?? null;
    if (!file) return;
    setSelectedFile(file);
    await parseUploadedFile(file);
  }

  async function handleSheetChange(nextSheet: string) {
    if (!selectedFile) return;
    await parseUploadedFile(selectedFile, nextSheet);
  }

  function handleTargetMappingChange(
    targetKey: ImportTargetFieldKey,
    columnKey: string,
  ) {
    setReport(null);
    setMapping((prev) => ({
      ...prev,
      [targetKey]: columnKey || null,
    }));
  }

  function handleToggleOrganiserRequired(targetKey: ImportTargetFieldKey) {
    if (baselineRequiredSet.has(targetKey)) return;
    setReport(null);
    setOrganiserRequiredFields((prev) =>
      prev.includes(targetKey)
        ? prev.filter((item) => item !== targetKey)
        : [...prev, targetKey],
    );
  }

  function handleAutoSuggestMappings() {
    if (!workbook) return;
    setReport(null);
    setMapping(suggestColumnMappings(workbook.sheet.columns));
  }

  function handleClearMappings() {
    setReport(null);
    setMapping(createEmptyMapping());
  }

  async function handleRunServerValidation() {
    if (!selectedEvent || !workbook) return;
    setValidateBusy(true);
    setErrorMessage(null);

    try {
      const response = await fetch("/api/imports/preview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          eventId: selectedEvent.id,
          columns: workbook.sheet.columns,
          rows: workbook.sheet.rows,
          mapping,
          requiredFields: organiserRequiredFields,
        }),
      });

      const payload = (await response.json()) as {
        ok: boolean;
        error?: string;
        report?: ImportValidationReport;
      };

      if (!response.ok || !payload.ok || !payload.report) {
        setErrorMessage(
          payload.error ?? "Server validation failed. Check your column mappings.",
        );
        return;
      }

      setReport(payload.report);
      setPreviewFilter("all");
      setStep(6);
    } catch {
      setErrorMessage(
        "Network error while running server-side import validation. Please retry.",
      );
    } finally {
      setValidateBusy(false);
    }
  }

  const filteredPreviewRows = useMemo(() => {
    if (!report) return [];
    switch (previewFilter) {
      case "valid":
        return report.previewRows.filter((r) => r.status === "valid");
      case "invalid":
        return report.previewRows.filter((r) => r.status === "invalid");
      case "duplicates":
        return report.previewRows.filter((r) => r.inFileDuplicates.length > 0);
      case "existing_matches":
        return report.previewRows.filter((r) => r.existingMatches.length > 0);
      default:
        return report.previewRows;
    }
  }, [report, previewFilter]);

  return (
    <div className="space-y-6">
      {migrationMissing ? (
        <div
          role="alert"
          className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900"
        >
          Stage 2A competition tables are not available yet. Apply migration{" "}
          <code className="font-mono text-xs">
            supabase/migrations/202611160003_stage2a_competition_structure.sql
          </code>{" "}
          before preparing registration imports.
        </div>
      ) : null}

      <div className="rounded-lg border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700">
        <div className="flex items-start gap-3">
          <ShieldCheck
            className="mt-0.5 h-4 w-4 shrink-0 text-[#4B0507]"
            aria-hidden="true"
          />
          <p className="leading-relaxed">
            <span className="font-semibold text-slate-900">
              Stage 2B.1 Preparation Mode:
            </span>{" "}
            Uploaded files are parsed and validated on the server without storing
            files in Supabase Storage or inserting records into the database.
          </p>
        </div>
      </div>

      {/* 6-Step Progress Bar */}
      <nav aria-label="Import preparation steps">
        <ol className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
          {STEP_LABELS.map((item) => {
            const isCurrent = step === item.step;
            const isReachable = item.step <= maxUnlockedStep;
            const isCompleted = item.step < step;
            return (
              <li key={item.step}>
                <button
                  type="button"
                  disabled={!isReachable}
                  onClick={() => {
                    if (isReachable) {
                      setErrorMessage(null);
                      setStep(item.step);
                    }
                  }}
                  className={`flex w-full items-center gap-2 rounded-md border px-3 py-2.5 text-left text-xs font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4B0507] ${
                    isCurrent
                      ? "border-[#4B0507] bg-[#4B0507] text-white"
                      : isReachable
                        ? "border-slate-200 bg-white text-slate-800 hover:bg-slate-50"
                        : "cursor-not-allowed border-slate-200 bg-slate-50 text-slate-400"
                  }`}
                >
                  <span
                    className={`font-mono text-xs tabular-nums ${
                      isCurrent
                        ? "text-white/90"
                        : isCompleted
                          ? "text-emerald-700"
                          : "text-slate-400"
                    }`}
                  >
                    {item.step}.
                  </span>
                  <span className="truncate">{item.title}</span>
                </button>
              </li>
            );
          })}
        </ol>
      </nav>

      {errorMessage ? (
        <div
          role="alert"
          className="flex items-start gap-2.5 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-900"
        >
          <XCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
          <span>{errorMessage}</span>
        </div>
      ) : null}

      {/* STEP 1: Select Event */}
      {step === 1 ? (
        <section
          aria-labelledby="step-1-heading"
          className="space-y-5 rounded-lg border border-slate-200 bg-white p-6"
        >
          <div className="space-y-1 border-b border-slate-100 pb-4">
            <h2
              id="step-1-heading"
              className="font-display text-lg font-semibold text-slate-900"
            >
              Step 1 · Select Target Event
            </h2>
            <p className="text-sm text-slate-600">
              Choose the Stage 2A competition event for which you are preparing
              registration records. Its configured entry mode governs validation.
            </p>
          </div>

          {events.length === 0 ? (
            <div className="space-y-3 rounded-md border border-slate-200 bg-slate-50 p-5 text-sm text-slate-700">
              <p>No competition events have been configured yet.</p>
              <Link
                href="/events"
                className="inline-flex min-h-10 items-center gap-2 rounded-md bg-[#4B0507] px-4 py-2 text-sm font-medium text-white hover:bg-[#380305]"
              >
                <span>Go to Events &amp; Rounds</span>
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Link>
            </div>
          ) : (
            <>
              <div className="space-y-2">
                <label
                  htmlFor="import-event-select"
                  className="block text-xs font-medium text-slate-700"
                >
                  Target Competition Event
                </label>
                <select
                  id="import-event-select"
                  value={selectedEventId}
                  onChange={(e) => handleSelectEvent(e.target.value)}
                  className="min-h-10 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-[#4B0507] focus:outline-none focus:ring-2 focus:ring-[#4B0507]/20"
                >
                  {events.map((evt) => (
                    <option key={evt.id} value={evt.id}>
                      {evt.code} — {evt.name} ({ENTRY_MODE_LABELS[evt.entry_mode]} ·{" "}
                      {EVENT_STATUS_LABELS[evt.status]})
                    </option>
                  ))}
                </select>
              </div>

              {selectedEvent ? (
                <div className="grid grid-cols-1 gap-4 rounded-md border border-slate-200 bg-slate-50 p-4 sm:grid-cols-2 lg:grid-cols-4">
                  <div>
                    <p className="text-xs text-slate-500">Event Code</p>
                    <p className="font-mono text-sm font-semibold text-slate-900">
                      {selectedEvent.code}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Entry Mode</p>
                    <p className="text-sm font-medium text-slate-900">
                      {ENTRY_MODE_LABELS[selectedEvent.entry_mode]}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Codename Mode</p>
                    <p className="text-sm font-medium text-slate-900">
                      {CODENAME_MODE_LABELS[selectedEvent.codename_mode]}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Event Status</p>
                    <p
                      className={`text-sm font-medium ${
                        selectedEvent.status === "archived"
                          ? "text-red-700"
                          : selectedEvent.status === "active"
                            ? "text-emerald-700"
                            : "text-slate-800"
                      }`}
                    >
                      {EVENT_STATUS_LABELS[selectedEvent.status]}
                    </p>
                  </div>
                </div>
              ) : null}

              {selectedEvent?.status === "archived" ? (
                <div
                  role="alert"
                  className="rounded-md border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900"
                >
                  This event is currently archived. You can still inspect and test
                  column mappings, but validation will flag all rows as ineligible
                  until the event is active or draft.
                </div>
              ) : null}

              <div className="flex justify-end border-t border-slate-100 pt-4">
                <button
                  type="button"
                  disabled={!selectedEvent}
                  onClick={() => setStep(2)}
                  className="inline-flex min-h-10 items-center gap-2 rounded-md bg-[#4B0507] px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-[#380305] disabled:opacity-50"
                >
                  <span>Continue to File Upload</span>
                  <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </button>
              </div>
            </>
          )}
        </section>
      ) : null}

      {/* STEP 2: Upload CSV or .xlsx */}
      {step === 2 ? (
        <section
          aria-labelledby="step-2-heading"
          className="space-y-5 rounded-lg border border-slate-200 bg-white p-6"
        >
          <div className="space-y-1 border-b border-slate-100 pb-4">
            <h2
              id="step-2-heading"
              className="font-display text-lg font-semibold text-slate-900"
            >
              Step 2 · Upload Registration Export
            </h2>
            <p className="text-sm text-slate-600">
              Upload a macro-free <code className="font-mono text-xs">.csv</code>{" "}
              or <code className="font-mono text-xs">.xlsx</code> spreadsheet
              exported from the college registration portal (maximum 5 MB, up to
              5,000 rows).
            </p>
          </div>

          <div className="rounded-lg border border-dashed border-slate-300 bg-slate-50 p-8 text-center">
            <FileSpreadsheet
              className="mx-auto h-10 w-10 text-[#4B0507]"
              aria-hidden="true"
            />
            <p className="mt-3 text-sm font-medium text-slate-900">
              {selectedFile
                ? `Selected: ${selectedFile.name} (${formatFileSize(selectedFile.size)})`
                : "Choose a .csv or .xlsx registration file"}
            </p>
            <p className="mt-1 text-xs text-slate-500">
              Macro-enabled workbooks (.xlsm, .xlsb, .xls) are blocked for safety.
              Duplicate headers and blank rows are handled cleanly.
            </p>

            <input
              ref={fileInputRef}
              type="file"
              accept=".csv,.xlsx,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
              onChange={handleFileInputChange}
              aria-label="Upload CSV or Excel registration file"
              className="sr-only"
            />

            <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                disabled={parseBusy}
                onClick={() => fileInputRef.current?.click()}
                className="inline-flex min-h-10 items-center gap-2 rounded-md bg-[#4B0507] px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-[#380305] disabled:opacity-50"
              >
                <Upload className="h-4 w-4" aria-hidden="true" />
                <span>
                  {parseBusy
                    ? "Parsing File..."
                    : workbook
                      ? "Upload a Different File"
                      : "Select File & Parse"}
                </span>
              </button>

              {workbook ? (
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="inline-flex min-h-10 items-center gap-2 rounded-md border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-800 hover:bg-slate-50"
                >
                  <span>Keep Current File &amp; Inspect Columns</span>
                  <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </button>
              ) : null}
            </div>
          </div>

          <div className="flex justify-between border-t border-slate-100 pt-4">
            <button
              type="button"
              onClick={() => setStep(1)}
              className="inline-flex min-h-10 items-center gap-2 rounded-md border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              <ArrowLeft className="h-4 w-4" aria-hidden="true" />
              <span>Back to Event Selection</span>
            </button>
          </div>
        </section>
      ) : null}

      {/* STEP 3: Inspect Detected Columns */}
      {step === 3 && workbook ? (
        <section
          aria-labelledby="step-3-heading"
          className="space-y-5 rounded-lg border border-slate-200 bg-white p-6"
        >
          <div className="flex flex-col gap-4 border-b border-slate-100 pb-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="space-y-1">
              <h2
                id="step-3-heading"
                className="font-display text-lg font-semibold text-slate-900"
              >
                Step 3 · Inspect Detected Columns
              </h2>
              <p className="text-sm text-slate-600">
                Parsed <span className="font-medium text-slate-900">{workbook.fileName}</span>{" "}
                ({formatFileSize(workbook.fileSizeBytes)} ·{" "}
                <span className="tabular-nums">{workbook.sheet.rows.length}</span> data
                rows,{" "}
                <span className="tabular-nums">{workbook.sheet.columns.length}</span>{" "}
                columns).
              </p>
            </div>

            {workbook.sheetNames.length > 1 && selectedFile ? (
              <div className="space-y-1">
                <label
                  htmlFor="xlsx-sheet-select"
                  className="block text-xs font-medium text-slate-700"
                >
                  Worksheet
                </label>
                <select
                  id="xlsx-sheet-select"
                  value={workbook.selectedSheetName}
                  disabled={parseBusy}
                  onChange={(e) => handleSheetChange(e.target.value)}
                  className="min-h-10 rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-[#4B0507] focus:outline-none"
                >
                  {workbook.sheetNames.map((name) => (
                    <option key={name} value={name}>
                      {name}
                    </option>
                  ))}
                </select>
              </div>
            ) : null}
          </div>

          {workbook.sheet.warnings.length > 0 ? (
            <div className="space-y-2 rounded-md border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
              <div className="flex items-center gap-2 font-medium">
                <AlertTriangle className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>File Structure Notices</span>
              </div>
              <ul className="list-disc space-y-1 pl-5 text-xs leading-relaxed">
                {workbook.sheet.warnings.map((warn, idx) => (
                  <li key={idx}>{warn}</li>
                ))}
              </ul>
            </div>
          ) : null}

          <div className="overflow-x-auto rounded-md border border-slate-200">
            <table className="min-w-full divide-y divide-slate-200 text-left text-sm">
              <thead className="bg-slate-50 text-xs font-semibold text-slate-700">
                <tr>
                  <th className="px-4 py-3">Col #</th>
                  <th className="px-4 py-3">Source Column Heading</th>
                  <th className="px-4 py-3">Non-Empty Rows</th>
                  <th className="px-4 py-3">Sample Values</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white">
                {workbook.sheet.columns.map((col) => (
                  <tr key={col.key}>
                    <td className="px-4 py-3 font-mono text-xs text-slate-500 tabular-nums">
                      {col.index + 1}
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-medium text-slate-900">
                        {col.headerName}
                      </div>
                      {col.isDuplicateHeader ? (
                        <p className="text-xs text-amber-700">
                          Duplicate heading ({col.duplicateOccurrence} of{" "}
                          {col.duplicateTotal})
                        </p>
                      ) : null}
                    </td>
                    <td className="px-4 py-3 font-mono text-xs text-slate-700 tabular-nums">
                      {col.nonEmptyCount} / {workbook.sheet.rows.length}
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-600">
                      {col.sampleValues.length > 0 ? (
                        col.sampleValues.join(" · ")
                      ) : (
                        <span className="text-slate-400">All blank</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex flex-wrap justify-between gap-3 border-t border-slate-100 pt-4">
            <button
              type="button"
              onClick={() => setStep(2)}
              className="inline-flex min-h-10 items-center gap-2 rounded-md border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              <ArrowLeft className="h-4 w-4" aria-hidden="true" />
              <span>Upload Different File</span>
            </button>
            <button
              type="button"
              onClick={() => setStep(4)}
              className="inline-flex min-h-10 items-center gap-2 rounded-md bg-[#4B0507] px-4 py-2 text-sm font-medium text-white hover:bg-[#380305]"
            >
              <span>Continue to Column Mapping</span>
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </button>
          </div>
        </section>
      ) : null}

      {/* STEP 4: Flexible Column Mapping */}
      {step === 4 && workbook && selectedEvent ? (
        <section
          aria-labelledby="step-4-heading"
          className="space-y-6 rounded-lg border border-slate-200 bg-white p-6"
        >
          <div className="flex flex-col gap-3 border-b border-slate-100 pb-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="space-y-1">
              <h2
                id="step-4-heading"
                className="font-display text-lg font-semibold text-slate-900"
              >
                Step 4 · Map Uploaded Columns to CMS Fields
              </h2>
              <p className="text-sm text-slate-600">
                Match your export&apos;s column names (in any order) to Stage 2A
                fields for{" "}
                <span className="font-medium text-slate-900">
                  {selectedEvent.code} ({ENTRY_MODE_LABELS[selectedEvent.entry_mode]})
                </span>
                .
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleAutoSuggestMappings}
                className="inline-flex min-h-10 items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-800 hover:bg-slate-50"
              >
                <Sparkles className="h-3.5 w-3.5 text-[#4B0507]" aria-hidden="true" />
                <span>Auto-Suggest</span>
              </button>
              <button
                type="button"
                onClick={handleClearMappings}
                className="inline-flex min-h-10 items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50"
              >
                <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Clear All</span>
              </button>
            </div>
          </div>

          {ENTITY_SECTION_META.map((section) => {
            const fields = IMPORT_FIELD_DEFINITIONS.filter(
              (f) => f.entity === section.entity,
            );
            return (
              <div key={section.entity} className="space-y-3">
                <div>
                  <h3 className="font-display text-base font-semibold text-slate-900">
                    {section.heading}
                  </h3>
                  <p className="text-xs text-slate-500">{section.description}</p>
                </div>

                <div className="divide-y divide-slate-200 rounded-md border border-slate-200">
                  {fields.map((field) => {
                    const isBaselineRequired = baselineRequiredSet.has(field.key);
                    const isRequired = effectiveRequiredSet.has(field.key);
                    const currentColKey = mapping[field.key] ?? "";

                    return (
                      <div
                        key={field.key}
                        className="grid grid-cols-1 gap-3 p-4 md:grid-cols-[1.2fr_1fr_auto] md:items-center"
                      >
                        <div className="space-y-0.5">
                          <div className="flex flex-wrap items-center gap-2">
                            <label
                              htmlFor={`map-${field.key}`}
                              className="text-sm font-medium text-slate-900"
                            >
                              {field.label}
                            </label>
                            {isRequired ? (
                              <span className="text-xs font-semibold text-[#4B0507]">
                                Required
                              </span>
                            ) : null}
                          </div>
                          <p className="text-xs text-slate-500">
                            {field.description}
                          </p>
                          <p className="font-mono text-[11px] text-slate-400">
                            {field.schemaColumn}
                          </p>
                        </div>

                        <div>
                          <select
                            id={`map-${field.key}`}
                            value={currentColKey}
                            onChange={(e) =>
                              handleTargetMappingChange(field.key, e.target.value)
                            }
                            className={`min-h-10 w-full rounded-md border bg-white px-3 py-2 text-sm text-slate-900 focus:border-[#4B0507] focus:outline-none focus:ring-2 focus:ring-[#4B0507]/20 ${
                              isRequired && !currentColKey
                                ? "border-amber-400"
                                : "border-slate-300"
                            }`}
                          >
                            <option value="">— Not mapped —</option>
                            {workbook.sheet.columns.map((col) => (
                              <option key={col.key} value={col.key}>
                                {col.displayLabel}
                              </option>
                            ))}
                          </select>
                        </div>

                        <label className="flex items-center gap-2 text-xs text-slate-700 md:justify-end">
                          <input
                            type="checkbox"
                            checked={isRequired}
                            disabled={isBaselineRequired}
                            onChange={() =>
                              handleToggleOrganiserRequired(field.key)
                            }
                            className="h-4 w-4 rounded border-slate-300 accent-[#4B0507]"
                          />
                          <span>
                            {isBaselineRequired
                              ? "Schema required"
                              : "Mark required"}
                          </span>
                        </label>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}

          {/* Unmapped Source Columns Inspection */}
          <div className="rounded-md border border-slate-200 bg-slate-50 p-4">
            <h3 className="text-sm font-semibold text-slate-900">
              Unmapped Uploaded Columns (
              <span className="tabular-nums">{unmappedSourceColumns.length}</span>)
            </h3>
            {unmappedSourceColumns.length === 0 ? (
              <p className="mt-1 text-xs text-slate-600">
                All uploaded spreadsheet columns are mapped to CMS fields.
              </p>
            ) : (
              <p className="mt-1 text-xs leading-relaxed text-slate-600">
                The following columns will be excluded from validation preview:{" "}
                <span className="font-medium text-slate-800">
                  {unmappedSourceColumns.map((c) => c.displayLabel).join(", ")}
                </span>
                .
              </p>
            )}
          </div>

          <div className="flex flex-wrap justify-between gap-3 border-t border-slate-100 pt-4">
            <button
              type="button"
              onClick={() => setStep(3)}
              className="inline-flex min-h-10 items-center gap-2 rounded-md border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              <ArrowLeft className="h-4 w-4" aria-hidden="true" />
              <span>Back to Inspect Columns</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setErrorMessage(null);
                setStep(5);
              }}
              className="inline-flex min-h-10 items-center gap-2 rounded-md bg-[#4B0507] px-4 py-2 text-sm font-medium text-white hover:bg-[#380305]"
            >
              <span>Continue to Validation</span>
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </button>
          </div>
        </section>
      ) : null}

      {/* STEP 5: Server-Side Validation Launch */}
      {step === 5 && workbook && selectedEvent ? (
        <section
          aria-labelledby="step-5-heading"
          className="space-y-5 rounded-lg border border-slate-200 bg-white p-6"
        >
          <div className="space-y-1 border-b border-slate-100 pb-4">
            <h2
              id="step-5-heading"
              className="font-display text-lg font-semibold text-slate-900"
            >
              Step 5 · Validate Records on the Server
            </h2>
            <p className="text-sm text-slate-600">
              Review your preparation configuration below, then run authoritative
              server-side validation against Stage 2A rules and read-only existing
              CMS records.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div className="rounded-md border border-slate-200 bg-slate-50 p-4">
              <p className="text-xs text-slate-500">Target Event</p>
              <p className="mt-1 text-sm font-semibold text-slate-900">
                {selectedEvent.code} · {selectedEvent.name}
              </p>
            </div>
            <div className="rounded-md border border-slate-200 bg-slate-50 p-4">
              <p className="text-xs text-slate-500">Rows to Validate</p>
              <p className="mt-1 font-mono text-lg font-semibold text-slate-900 tabular-nums">
                {workbook.sheet.rows.length}
              </p>
            </div>
            <div className="rounded-md border border-slate-200 bg-slate-50 p-4">
              <p className="text-xs text-slate-500">Mapped CMS Fields</p>
              <p className="mt-1 font-mono text-lg font-semibold text-slate-900 tabular-nums">
                {ALL_TARGET_FIELD_KEYS.length -
                  ALL_TARGET_FIELD_KEYS.filter((k) => !mapping[k]).length}
              </p>
            </div>
            <div className="rounded-md border border-slate-200 bg-slate-50 p-4">
              <p className="text-xs text-slate-500">Missing Required Mappings</p>
              <p
                className={`mt-1 font-mono text-lg font-semibold tabular-nums ${
                  missingRequiredBeforeValidate.length > 0
                    ? "text-amber-700"
                    : "text-emerald-700"
                }`}
              >
                {missingRequiredBeforeValidate.length}
              </p>
            </div>
          </div>

          {missingRequiredBeforeValidate.length > 0 ? (
            <div
              role="alert"
              className="rounded-md border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900"
            >
              The following required fields are not mapped yet:{" "}
              <span className="font-semibold">
                {missingRequiredBeforeValidate
                  .map((k) => IMPORT_FIELD_BY_KEY[k].label)
                  .join(", ")}
              </span>
              . You can return to Step 4 to map them or run validation now to
              inspect affected rows.
            </div>
          ) : null}

          <div className="flex flex-wrap justify-between gap-3 border-t border-slate-100 pt-4">
            <button
              type="button"
              onClick={() => setStep(4)}
              className="inline-flex min-h-10 items-center gap-2 rounded-md border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              <ArrowLeft className="h-4 w-4" aria-hidden="true" />
              <span>Back to Column Mapping</span>
            </button>
            <button
              type="button"
              disabled={validateBusy}
              onClick={handleRunServerValidation}
              className="inline-flex min-h-10 items-center gap-2 rounded-md bg-[#4B0507] px-5 py-2 text-sm font-medium text-white hover:bg-[#380305] disabled:opacity-50"
            >
              <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
              <span>
                {validateBusy
                  ? "Validating on Server..."
                  : "Run Server Validation & Build Preview"}
              </span>
            </button>
          </div>
        </section>
      ) : null}

      {/* STEP 6: Review Import Preview */}
      {step === 6 && report ? (
        <section
          aria-labelledby="step-6-heading"
          className="space-y-6 rounded-lg border border-slate-200 bg-white p-6"
        >
          <div className="flex flex-col gap-3 border-b border-slate-100 pb-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="space-y-1">
              <h2
                id="step-6-heading"
                className="font-display text-lg font-semibold text-slate-900"
              >
                Step 6 · Review Import Preview
              </h2>
              <p className="text-sm text-slate-600">
                Server validation summary for{" "}
                <span className="font-medium text-slate-900">
                  {report.event.code} — {report.event.name}
                </span>
                . Adjust column mappings or fix your source spreadsheet before
                Stage 2B.2 import execution.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setStep(4)}
              className="inline-flex min-h-10 shrink-0 items-center gap-2 rounded-md border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-800 hover:bg-slate-50"
            >
              <ArrowLeft className="h-4 w-4" aria-hidden="true" />
              <span>Back to Column Mapping</span>
            </button>
          </div>

          {/* Unboxed KPI Summary Counters (Stage 2A style) */}
          <dl className="grid grid-cols-2 gap-6 border-b border-slate-200 pb-6 sm:grid-cols-3 lg:grid-cols-6">
            <div>
              <dt className="text-xs font-medium text-slate-500">Total Rows</dt>
              <dd className="mt-1 font-display text-2xl font-bold text-slate-900 tabular-nums">
                {report.summary.totalRows}
              </dd>
            </div>
            <div>
              <dt className="text-xs font-medium text-slate-500">Valid Rows</dt>
              <dd className="mt-1 font-display text-2xl font-bold text-emerald-700 tabular-nums">
                {report.summary.validRows}
              </dd>
            </div>
            <div>
              <dt className="text-xs font-medium text-slate-500">Invalid Rows</dt>
              <dd className="mt-1 font-display text-2xl font-bold text-red-700 tabular-nums">
                {report.summary.invalidRows}
              </dd>
            </div>
            <div>
              <dt className="text-xs font-medium text-slate-500">
                In-File Duplicates
              </dt>
              <dd className="mt-1 font-display text-2xl font-bold text-amber-700 tabular-nums">
                {report.summary.inFileDuplicateRows}
              </dd>
            </div>
            <div>
              <dt className="text-xs font-medium text-slate-500">
                Existing CMS Matches
              </dt>
              <dd className="mt-1 font-display text-2xl font-bold text-slate-800 tabular-nums">
                {report.summary.existingMatchRows}
              </dd>
            </div>
            <div>
              <dt className="text-xs font-medium text-slate-500">
                Unmapped Columns
              </dt>
              <dd className="mt-1 font-display text-2xl font-bold text-slate-700 tabular-nums">
                {report.summary.unmappedSourceColumnsCount}
              </dd>
            </div>
          </dl>

          {report.batchNotices.length > 0 ? (
            <div className="space-y-1.5 rounded-md border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
              <p className="font-medium">Batch Validation Notices</p>
              <ul className="list-disc space-y-1 pl-5 text-xs">
                {report.batchNotices.map((notice, idx) => (
                  <li key={idx}>{notice}</li>
                ))}
              </ul>
            </div>
          ) : null}

          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap gap-2" role="tablist" aria-label="Filter preview rows">
              {(
                [
                  { id: "all", label: `All (${report.summary.totalRows})` },
                  { id: "valid", label: `Valid (${report.summary.validRows})` },
                  {
                    id: "invalid",
                    label: `Invalid (${report.summary.invalidRows})`,
                  },
                  {
                    id: "duplicates",
                    label: `In-File Duplicates (${report.summary.inFileDuplicateRows})`,
                  },
                  {
                    id: "existing_matches",
                    label: `Existing CMS Matches (${report.summary.existingMatchRows})`,
                  },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  role="tab"
                  aria-selected={previewFilter === tab.id}
                  onClick={() => setPreviewFilter(tab.id)}
                  className={`min-h-9 rounded-md border px-3 py-1.5 text-xs font-medium transition-colors ${
                    previewFilter === tab.id
                      ? "border-[#4B0507] bg-[#4B0507] text-white"
                      : "border-slate-300 bg-white text-slate-700 hover:bg-slate-50"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={handleRunServerValidation}
              disabled={validateBusy}
              className="inline-flex min-h-9 items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
            >
              <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Re-run Validation</span>
            </button>
          </div>

          {filteredPreviewRows.length === 0 ? (
            <div className="rounded-md border border-slate-200 bg-slate-50 p-6 text-center text-sm text-slate-600">
              No rows match the selected preview filter.
            </div>
          ) : (
            <div className="overflow-x-auto rounded-md border border-slate-200">
              <table className="min-w-full divide-y divide-slate-200 text-left text-xs sm:text-sm">
                <thead className="bg-slate-50 text-xs font-semibold text-slate-700">
                  <tr>
                    <th className="px-3 py-3">Row</th>
                    <th className="px-3 py-3">Status</th>
                    <th className="px-3 py-3">Entry</th>
                    <th className="px-3 py-3">Contingent / Institution</th>
                    <th className="px-3 py-3">Participant</th>
                    <th className="px-3 py-3">Validation Issues &amp; CMS Matches</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white align-top">
                  {filteredPreviewRows.map((row) => (
                    <tr
                      key={row.rowNumber}
                      className={row.status === "invalid" ? "bg-red-50/30" : ""}
                    >
                      <td className="px-3 py-3 font-mono text-xs text-slate-500 tabular-nums">
                        #{row.rowNumber}
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap">
                        <span
                          className={`text-xs font-semibold ${
                            row.status === "valid"
                              ? "text-emerald-700"
                              : "text-red-700"
                          }`}
                        >
                          {row.status === "valid" ? "Valid" : "Invalid"}
                        </span>
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-xs text-slate-700">
                        <div className="font-medium capitalize">
                          {row.resolvedEntryType}
                        </div>
                        <div className="text-slate-500">
                          {ENTRY_STATUS_LABELS[row.normalized.entryStatus]}
                        </div>
                      </td>
                      <td className="px-3 py-3 text-xs text-slate-700">
                        {row.normalized.contingent ? (
                          <div className="space-y-0.5">
                            <div className="font-medium text-slate-900">
                              {row.normalized.contingent.contingentCode ?? "—"}{" "}
                              {row.normalized.contingent.name
                                ? `· ${row.normalized.contingent.name}`
                                : ""}
                            </div>
                            <div className="text-slate-600">
                              {row.normalized.contingent.institutionName ?? "—"}
                            </div>
                          </div>
                        ) : (
                          <span className="text-slate-500">
                            {row.normalized.participant.institutionName ?? "Individual"}
                          </span>
                        )}
                      </td>
                      <td className="px-3 py-3 text-xs text-slate-700">
                        <div className="font-medium text-slate-900">
                          {row.normalized.participant.participantCode ?? "—"}{" "}
                          {row.normalized.participant.fullName
                            ? `· ${row.normalized.participant.fullName}`
                            : ""}
                        </div>
                        {row.normalized.participant.email ? (
                          <div className="text-slate-600">
                            {row.normalized.participant.email}
                          </div>
                        ) : null}
                        {row.normalized.participant.isContingentLead ? (
                          <div className="font-medium text-[#4B0507]">
                            Contingent Lead
                          </div>
                        ) : null}
                      </td>
                      <td className="px-3 py-3 text-xs">
                        {row.issues.length === 0 &&
                        row.existingMatches.length === 0 ? (
                          <span className="text-emerald-700">
                            Ready for Stage 2B.2 import
                          </span>
                        ) : (
                          <ul className="space-y-1">
                            {row.issues.map((issue, idx) => (
                              <li
                                key={`issue-${idx}`}
                                className={
                                  issue.severity === "error"
                                    ? "text-red-700"
                                    : "text-amber-700"
                                }
                              >
                                • {issue.message}
                              </li>
                            ))}
                            {row.existingMatches.map((match, idx) => (
                              <li
                                key={`match-${idx}`}
                                className={
                                  match.alreadyEnteredInSelectedEvent
                                    ? "font-medium text-amber-800"
                                    : "text-slate-600"
                                }
                              >
                                • {match.message}
                              </li>
                            ))}
                          </ul>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-4 text-xs text-slate-500">
            <span>
              Stage 2B.1 completes here. Importing validated records into
              Supabase tables and assigning codenames is scoped to Stage 2B.2.
            </span>
            <button
              type="button"
              onClick={() => setStep(2)}
              className="inline-flex min-h-9 items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
            >
              <Upload className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Prepare Another File</span>
            </button>
          </div>
        </section>
      ) : null}
    </div>
  );
}
